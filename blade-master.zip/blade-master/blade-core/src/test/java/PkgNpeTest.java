import com.hellokaton.blade.Blade;

/**
 * @author darren
 * @date 2019/10/16 16:59
 */
public class PkgNpeTest {

    public static void main(String[] args) {
        Blade.create()
                .start();
    }
}
