package com.hellokaton.blade.mvc.wrapper;

import org.junit.Test;

import java.io.IOException;

/**
 * @author biezhi
 * @date 2017/9/18
 */
public class OutputStreamWrapperTest {

    @Test
    public void verify_behaviour() throws IOException {

    }

}
