package com.hellokaton.blade.mvc;

import com.hellokaton.blade.BaseTestCase;

/**
 * Middleware Test
 *
 * @author biezhi
 * 2017/6/5
 */
public class MiddlewareTest extends BaseTestCase {

//    @Test
//    public void testAuthMiddleware() throws Exception {
//
//        BasicAuthMiddleware basicAuthMiddleware = mock(BasicAuthMiddleware.class);
//
//        Signature signature = mock(Signature.class);
//
//        basicAuthMiddleware.before(signature.routeContext());
//        basicAuthMiddleware.after(signature.routeContext());
//
//        verify(basicAuthMiddleware).before(signature.routeContext());
//        verify(basicAuthMiddleware).after(signature.routeContext());
//    }
}
