package com.hellokaton.blade.mvc;

import com.hellokaton.blade.BaseTestCase;
import org.junit.Test;

/**
 * @author biezhi
 * 2017/6/5
 */
public class SessionTest extends BaseTestCase {

    @Test
    public void testCreatedEvent() throws Exception {
//        start(
//                app.get("/", ((request, response) -> request.session()))
//                        .event(EventType.SESSION_CREATED, (e) -> {
//                            System.out.println("session 创建");
//                        })
//        );
//        bodyToString("/");
    }

}
