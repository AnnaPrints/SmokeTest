package com.hellokaton.blade.mvc.route;

public class RouteMatcherDemoController {
    public void index() {
    }

    public void remove() {
    }
}