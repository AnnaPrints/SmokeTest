package com.hellokaton.blade.kit.model;

import lombok.Data;

/**
 * @author ydq
 * @date 2020/3/21
 */
@Data
public class SuperBean {
    private String superField;
}
